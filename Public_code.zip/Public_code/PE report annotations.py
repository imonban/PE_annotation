
# coding: utf-8

# ## Utah test module

# In[37]:


import pandas as pd
import nltk
import sys
import codecs
import numpy as np
import gensim
from gensim.models import Word2Vec
import pickle
import re #regexes
import sys #command line arguments
import os, os.path
import string

nltk.download()
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer



def parse_impression_utah(full_report):
    '''
    Return the impression given the full text of the report
    or empty string if impression fails to parse
    Args:
        full_report : string representing the full report text
    Returns:
        string denoting the impression parsed from the full report.
        all words are converted to lower case
    '''
    impression_words = []
    #all_words = re.findall(r"[w']+", full_report)
    all_lines = full_report.split('.')
    start = False
    for index in range(len(all_lines)):
        line = all_lines[index].lower().strip()
        if len(line) == 0:
            continue
        if 'impression:' in line:
            start = True
        if start and ('report release date' in line                 or 'i have reviewed' in line                 or 'electronically reviewed by' in line                or 'electronically signed by' in line                 or 'attending md' in line                 or 'electronic signature by:' in line): 
            break
        if start:
            impression_words.append(line +'.')
    # Check if parsing failed
    if len([word for line in impression_words for word in line.split()]) < 2:
        return ''
    else:
        return '\n'.join(impression_words)
# Get input reports
path = './Reports/'
name = input("Enter file name where the files is stored in: "+path)
try:
    print(name)
    Utah_report =  pd.read_csv(path+name)
    print('Number of reports: '+str(Utah_report.shape[0]))
    Utah_report['report_text'] = Utah_report['Report Text'].apply(parse_impression_utah)
    print('File read: Impression extracted')
except:
    print('Please give a valid corpus: single CSV file with Report Text column')
    sys.exit()
    
#Step 4: text preprocessing functions
date_input = "" #global for date input (can be removed if we use lambdas later)
pairs = {} #global variable to count common pairs
exclude_list =  set(stopwords.words('english'))


def concatenate_into_string(infile):
    total_text = ""
    for line in infile:
        line = line.replace('\n', ' ')
        total_text += line
    return total_text


def substitute_word_for_digit(num,join=True):
    '''words = {} convert an integer number into words'''
    units = ['',' one ',' two ',' three ',' four ',' five ',' six ',' seven ',' eight ',' nine ']
    teens = ['',' eleven ',' twelve ',' thirteen ',' fourteen ',' fifteen ',' sixteen ',              ' seventeen ',' eighteen ',' nineteen ']
    tens = ['',' ten ',' twenty ',' thirty ',' forty ',' fifty ',' sixty ',' seventy ',             ' eighty ',' ninety ']
    thousands = ['',' thousand ',' million ',' billion ', ' trillion ',' quadrillion ',                  ' quintillion ',' sextillion ',' septillion ',' octillion ',                  ' nonillion ',' decillion ',' undecillion ',' duodecillion ',                  ' tredecillion ',' quattuordecillion ',' sexdecillion ',                  ' septendecillion ',' octodecillion ',' novemdecillion',                  ' vigintillion ']
    words = []
    if int(num)==0: words.append(' zero ')
    else:
        numStr = num
        numStrLen = len(numStr)
        groups = (numStrLen+2)/3
        groups = int(groups)
        numStr = numStr.zfill(groups*3)
        for i in range(0,groups*3,3):
            h,t,u = int(numStr[i]),int(numStr[i+1]),int(numStr[i+2])
            g = int(groups-(i/3+1))
            if h>=1:
                words.append(units[h])
                words.append(' hundred ')
            if t>1:
                words.append(tens[t])
                if u>=1: words.append(units[u])
            elif t==1:
                if u>=1: words.append(teens[u])
                else: words.append(tens[t])
            else:
                if u>=1: words.append(units[u])
            if (g>=1) and ((h+t+u)>0): words.append(thousands[g]+',')
    if join: return ' '.join(words)
    return words


def remove_forbidden_tokens(output, exclude_list):
    for item in exclude_list:
        output = re.sub(r""+re.escape(item)+r"", " ", output)
    return output



'''
The primary method. Takes input as a string and an exclusion list of strings and outputs a string.
'''
def preprocess(inputstr):
    #output = inputstr.lower() #tolowercase
    output = re.sub(r"(\d+)\/(\d+)\/(\d+) (\d+)\:(\d+)", ' ', inputstr) #processes dates of the form MM/DD/YYYY
    
    #output = re.sub(r'<>[#$=;&()"%\'\.\/\:\?\-,*+]', '', output) #remove special characters
    output = re.sub('['+string.punctuation+']', ' ', output)
    num = re.findall(r'\d+', output)
   #num = filter(str.isdigit, output)
    for i in num:
        wordnum = substitute_word_for_digit(i) #substitute single digit numbers with words
        #output = output.replace(i,wordnum)
        output = output.replace(i,' ') #try without the number
    #output = remove_forbidden_tokens(output, exclude_list)
    output = re.sub(r" +", " ", output) #remove extraneous whitespace
    return output

def dateprocess(date):
    string = str(date)
    splitdate = string.split()[0].split('-')
    newformatted = splitdate[2] +'/'+ splitdate[1]+'/'+splitdate[0]
    return newformatted 



def noteprocessing(rawnote):

    str1  = rawnote.lower();
    str1 = str1.replace('\n', ' ')
    phrase = 'i, the attending signed below, have personally reviewed the image and agree \n with the report transcribed above.'
    str1 = str1.replace(phrase,' ')  
    #str = str.replace('-', ' DASH ')
    #str = str.replace('.', ' DOT ')
    #str = str.replace(':',' COL ')
    str1 = str1.replace('%',' PERCENTAGE ')

    outputstr = preprocess(str1)
    stemmer = SnowballStemmer("english")
    #print(outputstr)
    #print exclude_list         
    words = outputstr.split(' ')
    words = [stemmer.stem(word) for word in words]
    newContent = ' '.join([word for word in words if word not in exclude_list])
    return newContent


#def remove_physicianDetails(s):
#    head, sep, tail  =  s.partition('CC')  
#    return head

##count the pair words in each note
def count_pair_words_doc(processednote):
    global pairs
    s = processednote.split('.')
    for i in s:
        x = i.split(' ')
        i = ' '.join(i.split())
        x = i.lstrip().rstrip().split(' ')
        for j in range(len(x) - 1):
            pairs[x[j] + ' ' + x[j + 1]] = pairs.get(x[j] + ' ' + x[j + 1], 0) + 1


#find commond pairs
def find_common_pairs(n):
    commonPairs = {}
    cutoff = 5000
    for pair in pairs.keys():
        if pairs[pair] > cutoff:
            commonPairs[pair] = pairs[pair]
            print(pairs[pair])
    return commonPairs


# In[3]:


def extract_entity_names(t):
    entity_names = []

    if hasattr(t, 'label') and t.label:
        if t.label() == 'PERSON' or t.label()=='LOCATION':
            entity_names.append(' '.join([child[0] for child in t]))
        else:
            for child in t:
                entity_names.extend(extract_entity_names(child))

    return entity_names


#compute the word map based on dictionary
GeneralwordMap = {}
Gterms = []
with open('./Dictionaries/clever_base_terminologyv2.txt', 'r') as termFile:
    for line in termFile:
        words = line.split('|')
        if len(words) == 3:
            GeneralwordMap[' ' + words[1].lstrip(' ').rstrip(' ') + ' '] = ' ' + words[2].replace('\n', '').lstrip(' ').rstrip(' ') + ' '
            Gterms.append(' ' + words[1].lstrip(' ').rstrip(' ') + ' ')
#print(Gterms)

#compute the word map based on dictionary
DomainwordMap = {}
Dterms = []
with open('./Dictionaries/PE_dic.txt', 'r') as termFile:
        for line in termFile:
                words = line.split('|')
                if len(words) == 2:
                        DomainwordMap[' ' + words[0].lstrip(' ').rstrip(' ') + ' '] = ' ' + words[1].replace('\n', '').lstrip(' ').rstrip(' ') + ' '
                        Dterms.append(' ' + words[0].lstrip(' ').rstrip(' ') + ' ')
                        #DomainwordMap[words[0].lstrip(' ').rstrip(' ') + ' '] = ' ' + words[1].replace('\n', '').lstrip(' ').rstrip(' ') + ' '
                        #Dterms.append(words[0].lstrip(' ').rstrip(' ') + ' ')
                        #DomainwordMap[' ' + words[0].lstrip(' ').rstrip(' ')] = ' ' + words[1].replace('\n', '').lstrip(' ').rstrip(' ') + ' '
                        #Dterms.append(' ' + words[0].lstrip(' ').rstrip(' '))
                        #DomainwordMap[ words[0].lstrip(' ').rstrip(' ')] = ' ' + words[1].replace('\n', '').lstrip(' ').rstrip(' ') + ' '
                        #Dterms.append( words[0].lstrip(' ').rstrip(' '))
                        
print('Dictionary loaded!!')



# In[4]:


def parse_impression_utah(full_report):
    '''
    Return the impression given the full text of the report
    or empty string if impression fails to parse
    Args:
        full_report : string representing the full report text
    Returns:
        string denoting the impression parsed from the full report.
        all words are converted to lower case
    '''
    impression_words = []
    #all_words = re.findall(r"[w']+", full_report)
    all_lines = full_report.split('.')
    start = False
    for index in range(len(all_lines)):
        line = all_lines[index].lower().strip()
        if len(line) == 0:
            continue
        if 'impression:' in line:
            start = True
        if start and ('i have personally reviewed' in line  or 'i have reviewed' in line or 'electronically reviewed by' in line  or 'electronically signed by' in line                 or 'attending md' in line                 or 'electronic signature by:' in line): 
            break
        if start:
            impression_words.append(line +'.')
    # Check if parsing failed
    if len([word for line in impression_words for word in line.split()]) < 2:
        return ''
    else:
        return '\n'.join(impression_words)





# In[6]:


Utah_report['report_text'] = Utah_report['Report Text'].apply(parse_impression_utah)


# ## Report pre-processing

# In[7]:


commonPairs = {'measur mm': 10289, 'risk need': 61148, 'measur x': 5156, 'discuss dr': 12847, 'deep venous': 5017, 'report transcrib': 97864, 'prior studi': 6528, 'left upper': 11443, 'x cm': 9619, 'coronari arteri': 5447, 'middl lobe': 7861, 'left pleural': 5279, 'right pleural': 5619, 'thorac aorta': 5878, 'signific chang': 5628, 'evid pe': 9305, 'abnorm previous': 15064, 'abov 0': 12762, 'report examin': 14216, 'metastat diseas': 25039, 'right lower': 16385, 'increas size': 14220, 'evid metastat': 5155, 'negex definit': 5689, 'embol ism': 6954, 'vertebr bodi': 5003, 'negex signific': 10984, 'attent follow': 12431, 'previous report': 15244, '0 00': 5662, 'risk repres': 12046, 'right middl': 8670, 'upper lobe': 24738, 'negex new': 6217, 'pleural effus': 19458, 'nodul right': 5507, 'compar prior': 8306, 'lymph node': 22796, 'chest abdomen': 10149, 'agre report': 97845, 'wall thicken': 5887, 'bilater pleural': 6354, 'signific abnorm': 17284, 'measur cm': 5920, 'decreas size': 9819, 'iliac arteri': 5520, 'examin agre': 97588, 'interv develop': 5223, 'need action': 60942, 'end examin': 6212, 'interv decreas': 6026, 'transcrib abov': 98021, 'ground glass': 11385, 'left lower': 14198, 'lower lobe': 31246, 'find risk': 51936, 'find discuss': 11798, 'abnorm chang': 12808, 'pulmonari embol': 5286, 'postsurg chang': 6530, 'end risk': 20289, 'chang risk': 13290, 'like repres': 8525, '0 0': 16438, 'nodul measur': 6139, 'action examin': 51709, 'within right': 6746, 'pulmonari nodul': 32886, 'possibl signific': 39224, 'status post': 12617, 'interv increas': 8977, 'risk signific': 21939, 'pulmonari arteri': 10804, 'right upper': 16074, 'negex evid': 39208, 'stabl appear': 7344, 'soft tissu': 17150, 'abdomen pelvi': 15919, 'negex exclud': 5455, 'glass opac': 6544, 'describ abov': 10214, 'signific find': 48484}


# In[8]:


df_temp = pd.DataFrame(columns=('report_id', 'modified_text'))
for i in range(Utah_report.shape[0]):
#text = " INPATIENT ATTENDING ONCOLOGIST: Dr. Dimitrios Colevas.       DATE OF ADMISSION: November 15, 2008.       DAY OF DISCHARGE: November 18, 2008.       ADMISSION DIAGNOSIS: Rule out upper gastrointestinal bleed in context of gastric carcinoma.       DISCHARGE DIAGNOSES:   1.  Gastric adenocarcinoma stage IV metastatic to lungs and liver. 2. History of stroke without residual deficit.   3.  Coronary artery disease, status post percutaneous transluminal coronary angioplasty x2.   4.  Chronic renal insufficiency, baseline creatinine 1.4-1.6. 5. Diabetes mellitus.   6.  Hypertension.   7.  History of PPD positive without previous treatment, history of BCG vaccination.   8.  History of pyelonephritis.       REASON FOR ADMISSION: Mr. Le is a very pleasant, Vietnamese speaking man with a recent diagnosis of gastric adenocarcinoma metastatic to liver and lung was admitted to the hospital to work up upper GI bleed elicited by history in Dr. Chu's clinic on November 15, 2008. Apparently ever since his colonoscopy at the end of September he has been having constant, black, tarry stool, worsening fatigue and weakness, and shortness of breath. History given to Dr. Chu and his fellow, Dr. Otis, was extremely concerning for occult GI bleed, and they felt him to be dehydrated on examination, and they admitted him to the hospital for an expedited work up for this problem.       HOSPITAL COURSE BY PROBLEM:   1.  Rule out upper GI bleed. Prior to admission, Dr. Chu contacted Dr. Visser of the general surgery service for possible palliative surgical intervention, namely a total gastrectomy was considered in your last resort should the patient have refractory GI bleeding. In the ITA, the patient's temperature was 36.6, his pulse was 79, and his blood pressure was 109/53. His hemoglobin was 9.9, his hematocrit 25.5, and his platelets 241. He was given IV fluids, and guaiac was deferred to floor management. At that time, we did not have access to the patient's previous records which include his laboratory values, cardiac catheterization, etc. He remained very weak, but arousable and interactive with stable vital signs, namely he did not display tachycardia or hypotension. He received 2 units of packed red blood cells as well as IV fluids, and his hematocrit increased from 25.4 to 31.2. He remained stable the rest of the hospitalization. Serial guaiacs of the stool were negative x3, and the patient had brown bowel movements while in house. Surgical consult was very attentive and did not feel that the patient was suitable for a radical operation. In addition, Radiation Oncology was consulted to review the records and the history with me and arrange to see him as an outpatient for the day following discharge.       Additional interventions including holding his Plavix and giving him p.o. vitamin K to correct his mild coagulopathy (he had an INR of 1.4). His INR at discharge 1.2. During the hospitalization, we had the luxury of obtaining outside hospital records which included recent laboratory values drawn at Good Samaritan. His hematocrit on daily blood draws from October 30 to November 8 ranged from 30-32. Further on review of the patient's indices and iron studies, it seems that his anemia is more consistent with anemia of chronic inflammation rather than acute blood loss. His MCV was within the normal range. His RDW was not elevated. His reticulocyte count was inappropriately low for his degree of anemia. His iron was low, and his ferritin was 969.       In summation, it is not clear that the patient suffered an occult or acute gastrointestinal bleed, however, we cannot rule this out. He certainly is at very high risk for the following reasons which justify this work up. He has a mild coagulopathy with an elevated INR. He has a large gastric mass, and he has anemia with a history of dark stools and progressive fatigue. Therefore, the patient's Plavix was discontinued. We reviewed his records from the outside hospital (his cardiac catheterizations have occurred at O'Connor Hospital and the last stent was placed in 2006 more than 2 years ago. Cardiology was consulted, and it was decided that regardless if this stent was a bare-metal or drug-eluting, it would be safe to discontinue Plavix this far out from the stent placement. His risk of upper GI bleeding certainly outweighs his benefit from Plavix use to prevent stent thrombosis). He was started on aspirin instead. In addition, he was given Protonix to take as an outpatient.       2. Metastatic gastric cancer. The patient has poorly differentiated gastric adenocarcinoma from an upper endoscopy/biopsy done at Good Samaritan Hospital earlier this month. In addition, he had a CT guided hepatic biopsy which confirmed the nodules seen in the liver are metastases from the stomach. Further, the patient has pulmonary nodules are presumed metastatic in nature. Overall, this is a very poor prognosis disease at stage IV and per NCCN guidelines the appropriate treatment, per discussion with his outpatient oncologist, include palliative therapy, delineating which form of palliation is appropriate depends on his performance status. It seems that his performance status was quite good prior to his current illness. However, at the present time, I am not sure it is clear that his performance status is such to indicate chemotherapy. His prognosis and diagnosis was communicated at length with his family members, including his daughter Tren, his daughter Hong, his son Tu, and his wife Di. The patient understands that he has stomach cancer, but it is unclear whether he fully understands the graveness of his prognosis. The family is very loving and supportive, and want what is best for their father, and the possibility of hospice was discussed which they seem to be amenable to. However, further discussion will be deferred to Dr. Chu for their clinic visit on the 21st.   3.  Hypertension. The patient presented taking 3 antihypertensive medications, 1 as a combination pill called Exforge which is a combination of a calcium channel blocker and an angiotensin receptor blocker. He was also taking clonidine 0.1 mg t.i.d. The combination pill was discontinued, and he was begun on a lower frequency clonidine 0.1 mg b.i.d. His blood pressure was stably low at 98-122 systolics.       4. Acute on chronic kidney injury. On admission, the patient's creatinine was 1.8. This improved overnight with hydration to 1.4. His creatinine at outside hospital review of laboratories ranged from 1.2 to 1.6.       5. Diabetes. The patient's fingerstick blood glucoses ranged from 100-145 during his hospitalization. He was placed on a sliding scale, and his glipizide was continued very low dose as an outpatient.       6. Coronary artery disease. The patient has a history of coronary disease and his results from his catheterization this year was obtained from O'Connor Hospital. The results were as follows. The left main was free of disease. The left anterior descending had mild diffuse disease with calcification and 30% stenosis in the proximal segment. The distal segment was free of disease. The left circumflex artery was tortuous and had a segment with most severe stenosis at 40%. The right coronary was a small caliber vessel with diffuse disease with most severe stenosis at 40%-50%. The conclusion of this study was triple vessel mild coronary disease most prominent in the proximal left anterior descending artery, proximal left circumflex, and proximal right coronary artery. At that time, the decision was for continuing medical management which included Plavix. Again in discussing the patient's case with cardiology, given the patient's risk and possible recent GI bleed, the Plavix was discontinued in favor of aspirin.       7. Gap metabolic acidosis. On admission, the patient had a gap of 10 which corrected to 16 with albumin. He was mildly uremic, and had lactate that was within normal limits. He did have ketones in his urine, and a beta hydroxybutyrate which was within normal range. He was given normal saline and converted to lactated Ringer's for hydration, and his bicarbonate subsequently improved from 19-21.       8. Hyponatremia with hyperkalemia. The patient had a mild hyponatremia and a mild hyperkalemia with a maximum potassium of 5.8 and a minimum sodium of 132. The patient had an a.m. cortisol check which was 16. Cortisol stim test was not done this hospitalization, but may be *** if he has a mild degree of adrenal insufficiency.       HOSPITAL PROCEDURES AND LABORATORIES:   1.  Chest x-ray done November 14, 2008, mild cardiomegaly and mild pulmonary edema.   2.  CT scan of chest, abdomen, and pelvis with contrast done November 17, 2008, showed gastric cancer of the cardia with a lesion in the gastric body with widespread metastatic disease including innumerable hepatic metastases, significant regional adenopathy throughout the upper abdomen and multiple small pulmonary nodules mostly in the right lobe of the lung. The gallbladder had wall edema which was nonspecific. There was cardiomegaly with small bilateral pleural effusions, and a mildly prominent pulmonary artery.   3.  Urine culture negative.   4.  A CBC at discharge: White count 11.9, 81% neutrophils, hemoglobin 10.4, hematocrit 30.5, platelets 218.   5.  Hepatitis B surface antigen negative.   6.  Hepatitis C antibody negative.   7.  Hepatitis B core antibody negative.   8.  Hepatitis A IgM negative.       DISCHARGE MEDICATIONS:   1.  Docusate 100 mg twice daily.   2.  Senna 8.6 mg tablets 2 tablets twice a day as needed for constipation.  3.  Protonix 40 mg daily.   4.  Clonidine 0.1 mg p.o. b.i.d.   5.  Aspirin 325 mg daily.   6.  Zofran 8 mg p.o. q. 8 hours as needed for nausea. 7. Crestor 5 mg daily.   8.  Glipizide 1.25 mg daily.       CONDITION ON DISCHARGE: Stable.       DISCHARGE FOLLOW UP: The patient will see Radiation Oncology in clinic on Thursday, November 20, 2008, and see Dr. Gilbert Chu of Stanford University Oncology on Friday, November 21, 2008, with laboratory tests.          Michael Koontz MD      Gilbert Chu, MD               D: 11/18/2008 11:11 P CT T: 11/19/2008 04:34 A CT / SPH Q1: Q2:   SJN:  24058157 DJN: 107946642    "
    #text = data.iloc[i]['report_text']
    print(i)
    text = Utah_report.iloc[i]['report_text']
    reportId = Utah_report.iloc[i]['Accession Number']
    sentences = nltk.sent_tokenize(text)
    tokenized_sentences = [nltk.word_tokenize(sentence) for sentence in sentences]
    tagged_sentences = [nltk.pos_tag(sentence) for sentence in tokenized_sentences]
    chunked_sentences = nltk.ne_chunk_sents(tagged_sentences, binary= False)


    entity_names = []
    for tree in chunked_sentences:
    # Print results per sentence
        #print (extract_entity_names(tree))
        entity_names.extend(extract_entity_names(tree))

# Print all entity names
#print entity_names

# Print unique entity names
#print (set(entity_names))

    my_string =  text
    for k in entity_names:
        my_string = my_string.replace(k, ' ')
        a = k.split(' ')
        for j in range(0,len(a)-1):
            insensitive = re.compile(re.escape(a[j]), re.IGNORECASE)
            my_string = insensitive.sub(' ', my_string)
            
    delete_list = ["impression:", "end of impression", "I, the attending signed below, have personally reviewed the images", "I have personally reviewed the images for this examination and agree with the report transcribed above.", "attending signed below", "MD", "Electronically Signed", "have personally reviewed the images", "and agree with the report transcribed above","Interpreted by Attending Radiologist"]

    for word in delete_list:
        my_string = my_string.replace(word, " ")
#print (my_string)




#2nd level of text processing and saving
#commonPairs =  find_common_pairs()
    stemmer = SnowballStemmer("english")


    modifiedContent =  my_string.lower()
    modifiedContent = re.sub(r"[\n\r]", " ", modifiedContent)
#uncomment for with semantic mapping
    for term in Dterms:
        if term in modifiedContent:
            modifiedContent = modifiedContent.replace(term, DomainwordMap[term])
            #print(term)
    
    
    for term in Gterms:
        if term in modifiedContent:
            modifiedContent = modifiedContent.replace(term, GeneralwordMap[term])
            #print(term)


    modifiedContent = noteprocessing(modifiedContent);
    count_pair_words_doc(modifiedContent)
    df_temp.loc[i] = [reportId, modifiedContent]


modified_report = []
    
#joining the commond pairs in the texts
for i in range(Utah_report.shape[0]):
    newContent = df_temp.iloc[i]['modified_text']
    newContent = re.sub(r'\d+', '', newContent)
    
    for pair in commonPairs.keys():
        p = pair.split(' ')
        if p[0].islower() and p[1].islower():
            newContent = newContent.replace(pair, str(p[0]) + '_' + str(p[1]))
    modified_report.append(newContent)
Utah_report['modified_report'] = modified_report


# ## Load pre-trained vector

# In[30]:


import logging
#word average approach
def word_averaging(word_vec, words):
    all_words= set()
    mean = [] 
    for word in words:
        
        if isinstance(word, np.ndarray):
            mean.append(word)
        elif word in word_vec.wv.vocab:
            #print(word)
            mean.append(word_vec[word])
            all_words.add(word_vec.wv.vocab[word].index)

    if not mean:
        logging.warning("cannot compute similarity with no input %s", words)
        # FIXME: remove these examples in pre-processing
        return np.zeros(300,)

    mean = gensim.matutils.unitvec(np.array(mean).mean(axis=0)).astype(np.float32)
    return mean

def  word_averaging_list(word_vec, text_list):
    return np.vstack([word_averaging(word_vec, review) for review in text_list ])


# In[17]:


#text tokenizing
def w2v_tokenize_text(text):
    tokens = []
    for sent in nltk.sent_tokenize(text, language='english'):
        for word in nltk.word_tokenize(sent, language='english'):
            if len(word) < 2:
                continue
            tokens.append(word)
    return tokens


# In[18]:


word_vec = Word2Vec.load("./Models/word2vec.model")


# ## vector generation

# In[31]:


import logging

test_col = []
for i in range(Utah_report.shape[0]):
    
    newContent = Utah_report.iloc[i]['modified_report']
    test_col.append(w2v_tokenize_text(newContent))


X_test_word_colaverage = word_averaging_list(word_vec,test_col)
print(len(X_test_word_colaverage))


# ## Load Classification

# In[33]:


# load the model from disk
classifier_positive = pickle.load(open('./Models/PEpositive.sav', 'rb'))
classifier_acute = pickle.load(open('./Models/PEacute.sav', 'rb'))


# In[34]:


# Predict the topics of the test set and compute 
# the evaluation metrics
y_col_pe_positive = classifier_positive.predict(X_test_word_colaverage)
y_col_pe_acute = classifier_acute.predict(X_test_word_colaverage)


# In[35]:


Utah_report['PE positive'] = y_col_pe_positive
Utah_report['PE acute'] = y_col_pe_acute


Utah_report = Utah_report.drop('modified_report', axis=1)

# In[36]:

output = input("Where to save the annotations: Enter file path + file name ")
try:
    Utah_report.to_csv(output)
    print('Saved annotated report in '+output)
except:
    print('Cannot save the annotated file. Please provide valid folder.')
    sys.exit()
      

